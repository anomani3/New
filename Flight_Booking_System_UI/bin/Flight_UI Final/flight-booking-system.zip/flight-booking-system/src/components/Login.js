import React, { useState } from 'react'
import { useHistory } from 'react-router-dom';
import AdminService from '../Services/AdminService'

const Login = () => {
  const [password, setpassword] = useState('')
  const [name, setname] = useState('')
  const [emailId, setemailId] = useState('')
  const [adminName, setstate] = useState('')
  const [contact, setcontact] = useState('')
  const [confirmpassword , setconfirmpassword ] = useState('')
  const history = useHistory();


  
  const adminLogin = (e) => {
    e.preventDefault();
    const AdminDetails = {name,emailId,adminName,contact,password,confirmpassword }
        AdminService.adminLogin(AdminDetails).then((response) => {
            var e=JSON.stringify(response.data);
            alert(e);
            history.push('/adminFlightList')
        }).catch(error => {
            console.log(error)
        })
    }

  return (
    <>
      <section className='showcase login'>
        <div className='showcase-overlay'>
          <form className='form-control'>
            <input
              type='email'
              name='username'
              id='username'
              value={name}
              onChange={(e) => setname(e.target.value)}
              placeholder='Enter Your username'
              required
            />
            <input type='password' name='password' id='password' placeholder='Enter Password'
              value={password}
              onChange={(e) => setpassword(e.target.value)}
            />
            <button className="btn btn-info" onClick={(e) => adminLogin(e)}>
              Submit
            </button>

          </form>
        </div>
      </section>
    </>
  )
}

export default Login
